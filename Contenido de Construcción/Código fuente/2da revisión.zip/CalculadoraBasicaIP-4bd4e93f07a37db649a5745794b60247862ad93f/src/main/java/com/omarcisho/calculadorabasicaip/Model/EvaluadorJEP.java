package com.omarcisho.calculadorabasicaip.Model;
import org.nfunk.jep.JEP;

public class EvaluadorJEP {

    public static String evaluaExpresion(String expression) {
        JEP jep = new JEP();
        jep.setImplicitMul(false);
        try {
            // Parseamos la expresión
            jep.parseExpression(expression);
            // Evaluamos la expresión
            double result = jep.getValue();

            // Verificamos si hay un error en la expresión
            if (jep.hasError()) {
                return "Error sintáctico";
            } else if (Double.toString(result).equals("Infinity") || Double.toString(result).equals("NaN")) {
                return "Error matemático";
            }

            if(result == -0){
                result = 0;
            }

            return String.format("%.2f", result);
        } catch (Exception e) {
            // Manejo de otros errores
            return "Error en la expresión";
        }
    }



}
