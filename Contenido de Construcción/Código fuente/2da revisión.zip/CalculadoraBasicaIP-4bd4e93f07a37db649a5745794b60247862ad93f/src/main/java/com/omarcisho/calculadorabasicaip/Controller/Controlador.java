package com.omarcisho.calculadorabasicaip.Controller;
import com.omarcisho.calculadorabasicaip.Model.EvaluadorJEP;
import com.omarcisho.calculadorabasicaip.Model.Operacion;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;

import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Controlador {

    /*Elementos graficos*/
    @FXML
    private TableColumn<Operacion, Integer> columnaNumeroOperacion;
    @FXML
    private TableColumn<Operacion, String> columnaOperacion;
    @FXML
    private TableColumn<Operacion, String> columnaResultado;
    @FXML
    private TableView<Operacion> tablaHistorial;
    @FXML
    private TextArea textAreaPantalla;

    /*Lista para el historial*/
    private ObservableList<Operacion> historialDeOperaciones = FXCollections.observableArrayList();

    /*Flags de control de operaciones
    * flagPuntoDecimal Indica cuando o no poner punto decimal
    * flagResultado Indica cuando lo que está en pantalla es un resultado
    * operacionPerpetua Indica cuando se puede dar = para repetir operacion */
     boolean flagPuntoDecimal = false;
     boolean flagResultado = false;
     boolean operacionPerpetua = false;

    /*Variables de control
    * ultimaOperacion almacena la última operación, sin guardar el resultado de la operacion anterior
    * indiceUltimoOperando almacena el indice en donde se encuentra el último operando de una operación */
     String ultimaOperacion;
     int indiceUltimoOperando;

    /*StringBuilders para el control de la operación
    * Cuando la operacion tiene únicamente enteros, se va almacenando en ladoEntero
    * Cuando aparece un punto decimal, el resto de la operación se coloca en el ladoDecimal
    * Cuando se presiona = o algún operando, lo que haya del lado entero o decimal se coloca en la operacion completa
    * */
     StringBuilder operacionCompleta = new StringBuilder();
     StringBuilder ladoEntero = new StringBuilder();
     StringBuilder ladoDecimal = new StringBuilder();

     private void colocaOperacionEnPantalla() {
         textAreaPantalla.clear();

         if(flagPuntoDecimal) {
             textAreaPantalla.setText(operacionCompleta + ladoEntero.toString() + ladoDecimal.toString());
         } else {
             textAreaPantalla.setText( operacionCompleta + ladoEntero.toString());
         }

         indiceUltimoOperando = buscaUltimaOperacion(textAreaPantalla.getText());
     }

    private void colocaCaracterDesdeBoton(Button boton) {
        if (flagPuntoDecimal) {
            ladoDecimal.append(boton.getText());
        } else {
            ladoEntero.append(boton.getText());
        }
    }

    private void colocaCaracterDesdeString(String digito) {
        if (flagPuntoDecimal) {
            ladoDecimal.append(digito);
        } else {
            ladoEntero.append(digito);
        }
    }

    public void botonNumericoPresionado(ActionEvent event) {
        if (flagResultado) {
            limpiaEntrada();
        }

        Button sourceButton = (Button) event.getSource();
        colocaCaracterDesdeBoton(sourceButton);

        colocaOperacionEnPantalla();
    }

    public void teclaFisicaPresionada(KeyEvent event) {
         if (flagResultado) {
             limpiaEntrada();
         }

         switch (event.getCode()) {
            case DIGIT0: case DIGIT1: case DIGIT2: case DIGIT3: case DIGIT4:
            case DIGIT5: case DIGIT6: case DIGIT7: case DIGIT8: case DIGIT9:
            case NUMPAD0: case NUMPAD1: case NUMPAD2: case NUMPAD3: case NUMPAD4:
            case NUMPAD5: case NUMPAD6: case NUMPAD7: case NUMPAD8: case NUMPAD9:
            case MULTIPLY: case DIVIDE: case ADD: case SUBTRACT: case DECIMAL:

                String digito = event.getText()
                        .replace("/", "÷")
                        .replace("*", "×");

                if (digito.equals(".")) {
                    colocaPuntoDecimal();
                } else {
                    colocaCaracterDesdeString(digito);
                }

                break;

            case ENTER:
                evalua();
                break;

            default:
                break;
        }
        colocaOperacionEnPantalla();
    }

    public void botonDeOperandoPresionado(ActionEvent event) {

        extraeParteDecimalYEntera();

        flagResultado = false;
        flagPuntoDecimal = false;

        botonNumericoPresionado(event);

        colocaOperacionEnPantalla();
    }

    private void extraeParteDecimalYEntera() {
        operacionCompleta.append(ladoEntero.toString()).append(ladoDecimal.toString());
        ladoEntero.setLength(0);
        ladoDecimal.setLength(0);
    }


    public void limpiaEntrada() {
         /*Resetamos absolutamente todo*/
         operacionCompleta.setLength(0);
         ladoDecimal.setLength(0);
         ladoEntero.setLength(0);

         flagPuntoDecimal = false;
         operacionPerpetua = false;
         flagResultado = false;

         textAreaPantalla.clear();
    }

    public void borraCaracter() {
         flagResultado = false; //Se va a manipular el resultado

         /*Se va borrando de derecha a izquierda, por ende la parte decimal va primero*/
        if(flagPuntoDecimal) { //Hay parte decimal
            if(ladoDecimal.length() == 1) { //Ya sólo queda el punto decimal
                ladoDecimal.setLength(0); //Explicitamente borramos toda la parte decimal
                flagPuntoDecimal = false; //Deshabilitamos el lado decimal
            } else { //Aún quedan decimales
                ladoDecimal.deleteCharAt(ladoDecimal.length() - 1); //Borra el último decimal
            }
        } else if (!ladoEntero.isEmpty()){ //Sólo hay numeros enteros
            ladoEntero.deleteCharAt(ladoEntero.length() - 1); //Borra el último entero
        }
        colocaOperacionEnPantalla();
    }

    public void colocaPuntoDecimal() {
        if(flagResultado){
            limpiaEntrada();
        }

         /*Se coloca un punto decimal sólo si la flag está abajo
         *Después de colocar el punto, se levanta la flag para evitar que se ponga otro punto decimal*/
         if(!flagPuntoDecimal || flagResultado) {
             ladoDecimal.append(".");
             flagPuntoDecimal = true;
         }

         /*Si no hay parte entera en la operación, o si no hay numeros en la parte entera, entonces se coloca un 0*/
         if(ladoEntero.isEmpty() || !ladoEntero.toString().matches(".*\\d.*")){
            ladoEntero.append("0");
        }
         colocaOperacionEnPantalla();
    }




    public void evalua() {

        if (textAreaPantalla.getText().isEmpty()) {
            return;
        }

        extraeParteDecimalYEntera();

        try {
        if ((operacionPerpetua) && (textAreaPantalla.getText().equals(historialDeOperaciones.getLast().getResultado()))) {
            operacionCompleta.append(ultimaOperacion);
            flagResultado = false;
        }
            operacionPerpetua = eliminaPrimerNumero(operacionCompleta.toString()).equals(ultimaOperacion);
        } catch (NoSuchElementException ignored){
        } 

        /*Psamos a String la operación completa y reemplazamos caracteres de operandos, por sus operandos
         * y se lo mandamos al evaluador de expresiones*/
        String operacionParaEvaluar = operacionCompleta.toString();

        String resultado = EvaluadorJEP.evaluaExpresion(operacionCompleta.toString()
                .replace("÷", "/")
                .replace("×", "*"));


        /*Intentamos pasar la expresión a double
        * Si se logra pasar, entonces el resultado es un número
        * De lo contrario, es un String de error*/

        try {
            Double.parseDouble(resultado);

            /*Borramos la operación actual y la reemplazamos con el resultado*/
            operacionCompleta.setLength(0);
            ladoEntero.append(resultado, 0, resultado.indexOf("."));
            ladoDecimal.append(resultado.substring(resultado.indexOf(".")));

            //Levantamos la flag de decimal, pues los resultados siempore tienen 2 decimales
            flagPuntoDecimal = true;

            //Finalmente se coloca el texto
            colocaOperacionEnPantalla();

        } catch (NumberFormatException e) {
            //Se muestra el error, pero no se añade al String Builder de operación, y limpiamos la operación
            textAreaPantalla.setText(resultado);
            operacionCompleta.setLength(0);
            flagResultado = true;
        } finally {
            //En cualquier caso, levantamos la bandera de resultado y añadimos al historial la operación

            if(buscaUltimaOperacion(operacionParaEvaluar) != -1 && !flagResultado){
                annadeOperacionAlHistorial(operacionParaEvaluar, resultado);
                ultimaOperacion = eliminaPrimerNumero(operacionParaEvaluar);
            }

            flagResultado = true;

        }
    }



    @FXML
    public void initialize() {
        inicializarTablaDeHistorial();
    }

    private void annadeOperacionAlHistorial(String operacion, String resultado) {
        historialDeOperaciones.add(new Operacion(historialDeOperaciones.size() + 1, operacion, resultado));
        tablaHistorial.refresh();
    }

//    private void borraHistorial() {
//         historialDeOperaciones.clear();
//         tablaHistorial.refresh();
//    }

    private void inicializarTablaDeHistorial() {
        columnaNumeroOperacion.setCellValueFactory(new PropertyValueFactory<>("numeroOperacion"));
        columnaOperacion.setCellValueFactory(new PropertyValueFactory<>("operacion"));
        columnaResultado.setCellValueFactory(new PropertyValueFactory<>("resultado"));

        historialDeOperaciones = FXCollections.observableArrayList();
        tablaHistorial.setItems(historialDeOperaciones);
    }

    private int buscaUltimaOperacion(String operacion) {
        Pattern expresion = Pattern.compile("[+×÷-]");
        Matcher cadena = expresion.matcher(operacion);

        int lastIndex = -1;
        while (cadena.find()) {
            lastIndex = cadena.start();
        }

        return lastIndex;
    }

    private String eliminaPrimerNumero(String operacion) {

         if(operacion.indexOf("-") == 0){
             operacion = operacion.substring(1);
         }

        Pattern expresion = Pattern.compile("[+×÷-]");
        Matcher cadena = expresion.matcher(operacion);

        int index = -1;
        while (cadena.find()) {
            index = cadena.start();
            break;
        }

        if (index == -1) {
            return ""; // Si no se encuentra ningún operador, se retorna una cadena vacía
        }

        return operacion.substring(index); // Retorna desde el primer operador hasta el final
    }



    public void borraUltimaOperacion() {
         if (indiceUltimoOperando > 0) {
             if (flagPuntoDecimal) {
                 operacionCompleta.append(ladoDecimal.toString());
             } else {
                 operacionCompleta.append(ladoEntero.toString());
             }

             operacionCompleta.delete(indiceUltimoOperando, operacionCompleta.length());

             ladoDecimal.setLength(0);
             ladoEntero.setLength(0);


             if (operacionCompleta.indexOf(".") >= 0) {
                 ladoEntero.append(operacionCompleta, 0, operacionCompleta.indexOf("."));
                 ladoDecimal.append(operacionCompleta.substring(operacionCompleta.indexOf(".")));
             } else {
                 ladoEntero.append(operacionCompleta);
             }

             operacionCompleta.setLength(0);
             colocaOperacionEnPantalla();
         } else {
             limpiaEntrada();
         }
    }



}