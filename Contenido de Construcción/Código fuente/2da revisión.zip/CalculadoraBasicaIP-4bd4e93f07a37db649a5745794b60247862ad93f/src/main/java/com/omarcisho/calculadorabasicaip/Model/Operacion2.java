package com.omarcisho.calculadorabasicaip.Model;

public record Operacion2(Integer numeroOperacion, String operacion, String resultado) {
}
