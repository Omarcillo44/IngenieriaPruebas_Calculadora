package com.omarcisho.calculadorabasicaip.App;

import com.omarcisho.calculadorabasicaip.Aplicacion;
import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(Aplicacion.class, args);
    }
}