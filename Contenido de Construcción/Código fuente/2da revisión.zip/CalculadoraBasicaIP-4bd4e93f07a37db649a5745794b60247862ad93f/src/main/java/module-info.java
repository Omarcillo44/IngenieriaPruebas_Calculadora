module com.omarcisho.calculadorabasicaip {
    requires javafx.controls;
    requires javafx.fxml;
    requires jep;


    opens com.omarcisho.calculadorabasicaip to javafx.fxml;
    exports com.omarcisho.calculadorabasicaip;
    exports com.omarcisho.calculadorabasicaip.Controller;
    opens com.omarcisho.calculadorabasicaip.Controller to javafx.fxml;
    exports com.omarcisho.calculadorabasicaip.Model; // Asegúrate de exportar este paquete

    opens com.omarcisho.calculadorabasicaip.Model to javafx.base;
    exports com.omarcisho.calculadorabasicaip.App;
    opens com.omarcisho.calculadorabasicaip.App to javafx.fxml; // Esta línea permite que javafx.base acceda a tu clase Operacion
}