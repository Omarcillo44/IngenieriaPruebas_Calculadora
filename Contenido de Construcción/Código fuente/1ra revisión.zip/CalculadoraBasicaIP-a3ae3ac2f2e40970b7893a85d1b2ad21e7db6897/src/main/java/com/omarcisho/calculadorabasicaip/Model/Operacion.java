package com.omarcisho.calculadorabasicaip.Model;

public class Operacion {
    private int numeroOperacion;
    private String operacion;
    private String resultado;

    public Operacion(int numeroOperacion, String operacion, String resultado) {
        this.numeroOperacion = numeroOperacion;
        this.operacion = operacion;
        this.resultado = resultado;
    }

    // Los getters deben ser exactamente como esto
    public int getNumeroOperacion() {
        return numeroOperacion;
    }

    public String getOperacion() {
        return operacion;
    }

    public String getResultado() {
        return resultado;
    }
}
