package com.omarcisho.calculadorabasicaip.Model;
import org.nfunk.jep.JEP;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EvaluadorJEP {

    public static String evaluaExpresion(String expression) {
        JEP jep = new JEP();
        jep.setImplicitMul(false);
        try {

            expression = aplicaPorcentajes(expression);

            // Parseamos la expresión
            jep.parseExpression(expression);
            // Evaluamos la expresión
            double result = jep.getValue();

            // Verificamos si hay un error en la expresión
            if (jep.hasError()) {
                return "Error sintáctico";
            } else if (Double.toString(result).equals("Infinity") || Double.toString(result).equals("NaN")) {
                return "Error matemático";
            }

            if(result == -0){
                result = 0;
            }

            return String.format("%.2f", result);
        } catch (Exception e) {
            // Manejo de otros errores
            return "Error en la expresión";
        }
    }

    private static String aplicaPorcentajes(String operacion) {

        if (!operacion.contains("%")) {
            return operacion;
        }

        Pattern expresion = Pattern.compile("\\d+(\\.\\d+)?%");
        Matcher cadena = expresion.matcher(operacion);

        StringBuilder operacionConPorcentajes = new StringBuilder();
        operacionConPorcentajes.append(operacion);

        while (cadena.find()) {

            operacionConPorcentajes.replace(
                    cadena.start(), cadena.end(),
                    String.valueOf(
                            (Double.parseDouble
                                    (
                                            operacion.substring(cadena.start(), cadena.end())
                                            .replace("%", ""))
                            )/100
                    )
            );

        }

        System.out.println(operacionConPorcentajes);
        return operacionConPorcentajes.toString();

    }


}
